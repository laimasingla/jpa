package com.cg.ibs.cardmanagement.service;

import java.math.BigInteger;

import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public interface DebitCustomerVerification {
	
	
	public boolean verifyDebitCardNumber(BigInteger debitCardNumber) throws IBSException;
	String verifyDebitcardType(BigInteger debitCardNumber) throws IBSException;
	public boolean verifyDebitPin(String pin, BigInteger debitCardNumber) throws IBSException;
	public boolean verifyAccountNumber(BigInteger accountNumber) throws IBSException;
	public boolean checkDebitTransactionId(String transactionId) throws IBSException;
	public boolean getDebitCardStatus(BigInteger debitCardNumber) throws IBSException;
	

}
