package com.cg.ibs.cardmanagement.bean;

public enum TransactionType {
	CREDIT, DEBIT;

}
