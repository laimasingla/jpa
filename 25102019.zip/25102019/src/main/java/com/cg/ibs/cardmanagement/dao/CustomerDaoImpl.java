package com.cg.ibs.cardmanagement.dao;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.apache.log4j.Logger;

import com.cg.ibs.cardmanagement.bean.AccountBean;
import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.bean.CreditCardBean;

import com.cg.ibs.cardmanagement.bean.CustomerBean;
import com.cg.ibs.cardmanagement.bean.DebitCardBean;

import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;
import com.cg.ibs.cardmanagement.ui.CardManagementUI;

public class CustomerDaoImpl implements CustomerDao {

	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("cardmanagement");
	EntityManager entityManager = entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction = entityManager.getTransaction();

	static Logger log = Logger.getLogger(CardManagementUI.class.getName());

	CaseIdBean caseIdObj = new CaseIdBean();
	DebitCardBean bean = new DebitCardBean();
	CreditCardBean bean1 = new CreditCardBean();
	CustomerBean bean2 = new CustomerBean();
	AccountBean bean3 = new AccountBean();

	@Override
	public String getNewName(BigInteger uci) throws IBSException {
		
		
		String name = "";
		
		return name;

	}

	@Override
	public boolean verifyUCI(BigInteger uci) throws IBSException {
		boolean result = false;

	/*	try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SqlQueries.VERIFY_UCI);) {
			preparedStatement.setBigDecimal(1, new BigDecimal(uci));

			try (ResultSet resultSet = preparedStatement.executeQuery();) {

				if (resultSet.next()) {
					result = true;
				}
			}
		} catch (Exception e) {

			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
*/
		return result;
	}

}
