package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.cardmanagement.bean.DebitCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public interface DebitCardTransactionDao {
	List<DebitCardTransaction> getDebitTrans(int dys, BigInteger debitCardNumber) throws IBSException;

	boolean verifyDebitTransactionId(String transactionId) throws IBSException;

	BigInteger getDebitCardNumber(String transactionId) throws IBSException;

	BigInteger getDMUci(String transactionId) throws IBSException;
}
