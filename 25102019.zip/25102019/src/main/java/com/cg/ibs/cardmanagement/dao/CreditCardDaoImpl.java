package com.cg.ibs.cardmanagement.dao;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.ibs.cardmanagement.JPAUtil.JpaUtilImpl;
import com.cg.ibs.cardmanagement.bean.CreditCardBean;
import com.cg.ibs.cardmanagement.bean.CustomerBean;
import com.cg.ibs.cardmanagement.bean.DebitCardBean;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class CreditCardDaoImpl implements CreditCardDao {

	private EntityManager entityManager;
	

	public CreditCardDaoImpl() {
		entityManager = JpaUtilImpl.getEntityManger();
	}

	public List<CreditCardBean> viewAllCreditCards() throws IBSException {

		TypedQuery<CreditCardBean> creditQuery = entityManager.createQuery(SqlQueries.SELECT_DATA_FROM_CREDIT_CARD,
				CreditCardBean.class);
		List<CreditCardBean> creditCards = creditQuery.getResultList();

		return creditCards;

	}

//	
//			LocalDateTime fromDate1 = LocalDateTime.now().minusDays(days);
//			LocalDateTime currentDate1 = LocalDateTime.now();
//			Timestamp timestamp1 = Timestamp.valueOf(fromDate1);
//			Timestamp timestamp2 = Timestamp.valueOf(currentDate1);
//			preparedStatement.setTimestamp(1, timestamp1);
//			preparedStatement.setTimestamp(2, timestamp2);
//			preparedStatement.setBigDecimal(3, new BigDecimal(debitCardNumber));
//

	@Override
	public boolean verifyCreditCardNumber(BigInteger creditCardNumber) throws IBSException {
		boolean result = false;

		CreditCardBean d = entityManager.find(CreditCardBean.class, creditCardNumber);

		if (d != null)
			result = true;

		return result;
	}

	@Override
	public void setNewCreditPin(BigInteger creditCardNumber, String newPin) throws IBSException {
		/*
		 * String sql = SqlQueries.SET_CREDIT_CARD_PIN; try (Connection connection =
		 * ConnectionProvider.getInstance().getConnection(); PreparedStatement
		 * preparedStatement = connection.prepareStatement(sql);) {
		 * 
		 * preparedStatement.setString(1, newPin); preparedStatement.setBigDecimal(2,
		 * new BigDecimal(creditCardNumber)); preparedStatement.executeUpdate();
		 * 
		 * } catch (Exception e) { throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		 * }
		 */
	}

	@Override
	public String getCreditCardPin(BigInteger creditCardNumber) throws IBSException {
		String creditCardPin = null;
		/*
		 * String sql = SqlQueries.GET_CREDIT_CARD_PIN;
		 * 
		 * try (Connection connection =
		 * ConnectionProvider.getInstance().getConnection(); PreparedStatement
		 * preparedStatement = connection.prepareStatement(sql)) {
		 * preparedStatement.setBigDecimal(1, new BigDecimal(creditCardNumber));
		 * 
		 * ResultSet resultSet = preparedStatement.executeQuery();
		 * 
		 * while (resultSet.next()) {
		 * 
		 * creditCardPin = resultSet.getString("credit_cur_pin");
		 * 
		 * }
		 * 
		 * } catch (Exception e) { throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		 * 
		 * }
		 */
		return creditCardPin;

	}

	@Override
	public BigInteger getCreditUci(BigInteger creditCardNumber) throws IBSException {
		TypedQuery<CustomerBean> query=entityManager.createQuery("select c.uci from CreditCardBean c join  c.custBeanObject d where c.cardNumber=?1",CustomerBean.class);
		query.setParameter(1,creditCardNumber);
		CustomerBean temp = (CustomerBean) query.getSingleResult();
		 BigInteger UCI=temp.getUCI();
		 return UCI;

	}

	@Override
	public String getcreditCardType(BigInteger creditCardNumber) throws IBSException {
	
	
		
		TypedQuery<CreditCardBean> query=entityManager.createQuery("select c from CreditCardBean c where c.cardNumber=?1",CreditCardBean.class);
		query.setParameter(1,creditCardNumber);
		CreditCardBean temp = (CreditCardBean) query.getSingleResult();
		String type = temp.getCardType();
		return type;
	}

	@Override
	public String getCreditCardStatus(BigInteger creditCardNumber) throws IBSException {
		TypedQuery<CreditCardBean> query=entityManager.createQuery("select d from CreditCardBean d where d.cardNumber=?1",CreditCardBean.class);
		query.setParameter(1,creditCardNumber);
		CreditCardBean temp = (CreditCardBean) query.getSingleResult();
		String status = temp.getCardStatus();
		return status;
	}

	@Override
	public boolean actionANCC(String queryId, CreditCardBean bean1) throws IBSException {
		boolean result = false;
		/*
		 * BigInteger uci = null;
		 * 
		 * try (Connection connection =
		 * ConnectionProvider.getInstance().getConnection(); PreparedStatement
		 * preparedStatement = connection
		 * .prepareStatement(SqlQueries.GET_DETAILS_CREDIT_CARD_NEW);) {
		 * preparedStatement.setString(1, queryId); try (ResultSet resultSet =
		 * preparedStatement.executeQuery()) { while (resultSet.next()) { uci =
		 * resultSet.getBigDecimal("UCI").toBigInteger(); } } } catch (SQLException |
		 * IOException e) { throw new IBSException(ErrorMessages.INTERNAL_ERROR); } try
		 * (Connection connection = ConnectionProvider.getInstance().getConnection();
		 * PreparedStatement preparedStatement2 = connection
		 * .prepareStatement(SqlQueries.ACTION_CREDIT_CARD_NEW);) {
		 * preparedStatement2.setBigDecimal(1, new BigDecimal(bean1.getCardNumber()));
		 * preparedStatement2.setString(2, bean1.getCardStatus());
		 * preparedStatement2.setString(3, bean1.getNameOnCard());
		 * preparedStatement2.setString(4, bean1.getCvvNum());
		 * preparedStatement2.setString(5, bean1.getCurrentPin());
		 * preparedStatement2.setDate(6,
		 * java.sql.Date.valueOf(bean1.getDateOfExpiry()));
		 * preparedStatement2.setBigDecimal(7, new BigDecimal(uci));
		 * preparedStatement2.setString(8, bean1.getCardType());
		 * preparedStatement2.setInt(9, bean1.getCreditScore());
		 * preparedStatement2.setBigDecimal(10, bean1.getCreditLimit());
		 * preparedStatement2.setDouble(11, bean1.getIncome()); if
		 * (preparedStatement2.executeUpdate() > 0) { result = true; }
		 * 
		 * } catch (SQLException | IOException e) { throw new
		 * IBSException(ErrorMessages.INTERNAL_ERROR); }
		 */
		return result;
	}

	@Override
	public void actionBlockCC(String queryId, String status) throws IBSException {
		/*
		 * BigInteger creditCardNum = null; // String creditCardStatus = ""; try
		 * (Connection connection = ConnectionProvider.getInstance().getConnection();
		 * PreparedStatement preparedStatement =
		 * connection.prepareStatement(SqlQueries.GET_DETAILS_CARD_BLOCK)) {
		 * preparedStatement.setString(1, queryId); try (ResultSet resultSet =
		 * preparedStatement.executeQuery()) { while (resultSet.next()) { creditCardNum
		 * = resultSet.getBigDecimal("card_num").toBigInteger(); // creditCardStatus =
		 * resultSet.getString("define_query"); } } } catch (Exception e) { throw new
		 * IBSException(ErrorMessages.INTERNAL_ERROR); } try (Connection connection =
		 * ConnectionProvider.getInstance().getConnection(); PreparedStatement
		 * preparedStatement2 = connection
		 * .prepareStatement(SqlQueries.ACTION_CREDIT_CARD_BLOCK);) {
		 * preparedStatement2.setString(1, status); preparedStatement2.setBigDecimal(2,
		 * new BigDecimal(creditCardNum)); preparedStatement2.executeUpdate(); } catch
		 * (Exception e) { throw new IBSException(ErrorMessages.INTERNAL_ERROR); }
		 */

	}

	@Override
	public void actionUpgradeCC(String queryId) throws IBSException {
		/*
		 * BigInteger creditCardNum = null; String creditCardType = ""; try (Connection
		 * connection = ConnectionProvider.getInstance().getConnection();
		 * PreparedStatement preparedStatement = connection
		 * .prepareStatement(SqlQueries.GET_DETAILS_CARD_UPGRADE);) {
		 * preparedStatement.setString(1, queryId); try (ResultSet resultSet =
		 * preparedStatement.executeQuery()) { while (resultSet.next()) { creditCardNum
		 * = resultSet.getBigDecimal("card_num").toBigInteger(); creditCardType =
		 * resultSet.getString("define_query"); } } } catch (Exception e) { throw new
		 * IBSException(ErrorMessages.INTERNAL_ERROR); } try (Connection connection =
		 * ConnectionProvider.getInstance().getConnection(); PreparedStatement
		 * preparedStatement2 = connection
		 * .prepareStatement(SqlQueries.ACTION_CREDIT_CARD_UPGRADE)) {
		 * preparedStatement2.setString(1, creditCardType);
		 * preparedStatement2.setBigDecimal(2, new BigDecimal(creditCardNum));
		 * preparedStatement2.executeUpdate(); } catch (Exception e) { throw new
		 * IBSException(ErrorMessages.INTERNAL_ERROR); }
		 * 
		 * }
		 */

	}
}
