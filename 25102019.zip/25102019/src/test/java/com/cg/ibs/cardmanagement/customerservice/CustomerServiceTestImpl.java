package com.cg.ibs.cardmanagement.customerservice;

//import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.fail;

import java.math.BigInteger;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import com.cg.ibs.cardmanagement.bean.CreditCardBean;
import com.cg.ibs.cardmanagement.bean.DebitCardBean;
import com.cg.ibs.cardmanagement.dao.CustomerDaoImpl;
import com.cg.ibs.cardmanagement.dao.CustomerDao;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;
import com.cg.ibs.cardmanagement.service.CreditCustomer;
import com.cg.ibs.cardmanagement.service.CreditCustomerClassImpl;
import com.cg.ibs.cardmanagement.service.CreditCustomerVerification;
import com.cg.ibs.cardmanagement.service.CreditCustomerVerificationImpl;
import com.cg.ibs.cardmanagement.service.CustomerService;
import com.cg.ibs.cardmanagement.service.CustomerServiceImpl;
import com.cg.ibs.cardmanagement.service.DebitCustomer;
import com.cg.ibs.cardmanagement.service.DebitCustomerClassImpl;
import com.cg.ibs.cardmanagement.service.DebitCustomerVerification;
import com.cg.ibs.cardmanagement.service.DebitCustomerVerificationImpl;

public class CustomerServiceTestImpl {

	CustomerService customerService = new CustomerServiceImpl();
	CustomerDao dao = new CustomerDaoImpl();
	
	CreditCustomerVerification creditVerify = new CreditCustomerVerificationImpl();
	CreditCustomer creditCustomer = new CreditCustomerClassImpl();

	DebitCustomer debitCustomer= new DebitCustomerClassImpl();
	DebitCustomerVerification debitVerify = new DebitCustomerVerificationImpl();

	@Test
	void verifyNonExistingDebitCardNumber() {
		BigInteger debitCardNumber = new BigInteger("5456767717123456");
		Assertions.assertThrows(IBSException.class, () -> {
			debitVerify.verifyDebitCardNumber(debitCardNumber);
		});
	}

	@Test
	void verifyExistingDebitCardNumber() {
		BigInteger debitCardNumber = new BigInteger("5234567891012131");
		try {
			assertEquals(true, debitVerify.verifyDebitCardNumber(debitCardNumber));
		} catch (IBSException e) {
			fail(e.getMessage());
		}

	}

	@Test
	void verifyNonExistingAccountNumber() {
		BigInteger accountNumber = new BigInteger("5234567891012131");
		Assertions.assertThrows(IBSException.class, () -> {
			debitVerify.verifyAccountNumber(accountNumber);
		});
	}

	@Test
	void verifyExistngAccountNumber() {
		BigInteger accountNumber = new BigInteger("12345678910");
		try {
			assertEquals(true, debitVerify.verifyAccountNumber(accountNumber));
		} catch (IBSException e) {
			fail("Test failed : " + e.getMessage());
		}

	}
	
	@Test
	void verifyNonExistingCreditCardNumber() {
		BigInteger creditCardNumber = new BigInteger("523456789101287");
		Assertions.assertThrows(IBSException.class, () -> {
			creditVerify.verifyCreditCardNumber(creditCardNumber);
		});
	}

	@Test
	void verifyExistngCreditCardNumber() {
		BigInteger creditCardNumber = new BigInteger("5189101213259898");
		try {
			assertEquals(true, creditVerify.verifyCreditCardNumber(creditCardNumber));
		} catch (IBSException e) {
			fail("Test failed : " + e.getMessage());
		}

	}

	





	@Test
	void getNewCardtypeWithValidInput() {
		int cardType = 2;
		try {
			assertEquals("Gold", customerService.getNewCardtype(cardType));
		} catch (IBSException e) {
			fail("Test failed : " + e.getMessage());
		}
	}

	@Test
	void getNewCardtypeWithInvalidInput() {
		int cardType = 5;
		Assertions.assertThrows(IBSException.class, () -> {
			customerService.getNewCardtype(cardType);
		});

	}

	@Test
	void requestDebitCardLostWithValidInput() {
		BigInteger debitCardNumber = new BigInteger("5234567891012131");
		try {
			assertNotNull(
					debitCustomer.requestDebitCardLost(debitCardNumber));
		} catch (IBSException e) {
			fail("Test failed : " + e.getMessage());
		}
	}



	@Test
	void requestCreditCardLostWithValidInput() {
		BigInteger creditCardNumber = new BigInteger("5189101213259898");
		try {
			assertNotNull(
					creditCustomer.requestCreditCardLost(creditCardNumber));
		} catch (IBSException e) {
			fail("Test failed : " + e.getMessage());
		}
	}



	@Test
	void raiseDebitMismatchTicketWithValidInput() {
		String transactionId = "DEB101";
		try {
			assertNotNull(
					debitCustomer.raiseDebitMismatchTicket(transactionId));
		} catch (IBSException e) {
			fail("Test failed : " + e.getMessage());
		}
	}

	


	
		
		@Test
		void viewAllDebitCards() {
		try {
			assertNotNull(debitCustomer.viewAllDebitCards());
		} catch (IBSException e) {
			
			e.printStackTrace();
		}
	    					
		}
		

		@Test
		void viewAllCreditCards() {
			try {
				assertNotNull(creditCustomer.viewAllCreditCards());
			} catch (IBSException e) {
			
				e.printStackTrace();
			}
		
						
		}
		
		@Test
		void requestDebitCardUpgradeWithValidInput() {
			BigInteger debitCardNumber = new BigInteger("5221562391012233");
			String myChoice="1";
			try {
				assertNotNull(debitCustomer.requestDebitCardUpgrade(debitCardNumber, myChoice));
			} catch (IBSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		
		
		
	
	}



